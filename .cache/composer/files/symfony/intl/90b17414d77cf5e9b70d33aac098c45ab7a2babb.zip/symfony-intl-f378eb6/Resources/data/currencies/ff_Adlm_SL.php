<?php

return [
    'Names' => [
        'GNF' => [
            0 => 'GNF',
            1 => '𞤊𞤢𞤪𞤢𞤲 𞤘𞤭𞤲𞤫𞤲𞤳𞤮',
        ],
        'SLE' => [
            0 => 'Le',
            1 => 'SLE',
        ],
    ],
];
