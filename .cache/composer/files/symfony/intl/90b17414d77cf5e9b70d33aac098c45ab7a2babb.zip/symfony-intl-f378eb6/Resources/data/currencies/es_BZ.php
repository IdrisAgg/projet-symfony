<?php

return [
    'Names' => [
        'BZD' => [
            0 => '$',
            1 => 'dólar beliceño',
        ],
    ],
];
