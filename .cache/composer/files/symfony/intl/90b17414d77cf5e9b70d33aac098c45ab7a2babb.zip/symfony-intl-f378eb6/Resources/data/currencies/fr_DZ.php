<?php

return [
    'Names' => [
        'DZD' => [
            0 => 'DA',
            1 => 'dinar algérien',
        ],
    ],
];
