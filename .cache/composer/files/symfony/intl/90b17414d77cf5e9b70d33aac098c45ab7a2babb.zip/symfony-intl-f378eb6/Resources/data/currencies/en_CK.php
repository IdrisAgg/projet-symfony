<?php

return [
    'Names' => [
        'NZD' => [
            0 => '$',
            1 => 'New Zealand Dollar',
        ],
    ],
];
