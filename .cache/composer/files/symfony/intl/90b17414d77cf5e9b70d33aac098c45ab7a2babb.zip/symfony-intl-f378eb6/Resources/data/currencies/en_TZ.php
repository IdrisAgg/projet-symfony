<?php

return [
    'Names' => [
        'TZS' => [
            0 => 'TSh',
            1 => 'Tanzanian Shilling',
        ],
    ],
];
