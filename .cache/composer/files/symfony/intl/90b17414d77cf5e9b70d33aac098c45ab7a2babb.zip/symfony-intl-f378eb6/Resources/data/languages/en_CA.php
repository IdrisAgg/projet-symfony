<?php

return [
    'Names' => [
        'bn' => 'Bengali',
        'mfe' => 'Mauritian Creole',
    ],
    'LocalizedNames' => [
        'ar_001' => 'Arabic (Modern Standard)',
        'nds_NL' => 'West Low German',
        'ro_MD' => 'Moldovan',
        'zh_Hans' => 'simplified Chinese',
        'zh_Hant' => 'traditional Chinese',
    ],
];
