<?php

return [
    'Names' => [
        'SGD' => [
            0 => '$',
            1 => 'Singapore Dollar',
        ],
    ],
];
