<?php

return [
    'Names' => [
        'GBP' => [
            0 => 'GB£',
            1 => 'British Pound',
        ],
        'GIP' => [
            0 => '£',
            1 => 'Gibraltar Pound',
        ],
    ],
];
