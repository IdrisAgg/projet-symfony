<?php

return [
    'Names' => [
        'SRD' => [
            0 => '$',
            1 => 'Surinaamse dollar',
        ],
    ],
];
