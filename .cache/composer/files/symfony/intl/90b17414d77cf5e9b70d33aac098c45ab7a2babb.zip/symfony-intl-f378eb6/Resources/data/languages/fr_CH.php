<?php

return [
    'Names' => [
        'gu' => 'goudjrati',
        'pdc' => 'allemand de Pennsylvanie',
        'sdh' => 'kurde méridional',
    ],
    'LocalizedNames' => [
    ],
];
